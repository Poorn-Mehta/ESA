/* ========================================
 * ECEN 5053-003 ESA LAB 6 (PID Control)
 * 
 * Created by: Rushi James Macwan and 
 *             Poorn Mehta
 *
 * FALL 2018 - 12/08/2018
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define SAMPLES 200

#define p 150
#define d 100
#define i 800

#define ref 100

/*.................Global Variables.......................*/

int8 Vmeas_raw;

uint8 dac_in;
uint8 x;

int32 Vmeas, Vmeas_last, Vmeas_delta, Verror, Vmeas_buffer[SAMPLES];
int32 Verror_sum, Verror_sum_limited = 1000;
int32 Kd_scale_factor = 150, Kp_scale_factor = 100, Ki_scale_factor = 800;
int32 Kd_term, Kp_term, Ki_term;
int32 Vout;
int32 Kp = 1000, Kd = 3000, Ki = 1000;

uint32 loop_count;

/*................Functions................*/

void func_1(int32 Vref, uint32 Z, int32 FF_term); // Vref --> reference value; Z --> scaling factor (to evade the voltage tripping); FF_term --> base factor

/*................MAIN.....................*/

int main(void)
{
    CyGlobalIntEnable; 
    ADC_Start();
    DAC_1_Start(); DAC_2_Start(); DAC_3_Start();
    OA_1_Start(); OA_2_Start(); OA_3_Start(); OA_4_Start();
	
	/*.......while loop........*/   
    
    while(1)
    {
        int32 Vref = 140; int32 FF_term = 110; uint32 Z = 90;
        func_1(Vref, Z, FF_term);
        
        // Decreasing Vref by 20 counts; FF_term by 10 counts; Scaling factor by 10 counts
        
        Vref = 120; FF_term = 100; Z = 80;
        func_1(Vref, Z, FF_term);
        
        // Decreasing Vref by 20 counts; FF_term by 10 counts; Scaling factor by 10 counts
        
        Vref = 100; FF_term = 90; Z = 70;
        func_1(Vref, Z, FF_term);    
    }
}

void func_1(int32 Vref,  uint32 Z, int32 FF_term)
{
    int count = 0; 
    while(1)
    {   
        count++;
        
        if(count >= 1000)
        {
            CyDelay(5);
            break;
        }        
        
        DAC_2_SetValue(Z); // scaled Vref with appropriate display gain
        DAC_3_SetValue(dac_in); // Vout measured with proper 0-255 scaling without any errors
            
        Vmeas_last = Vmeas;        
        
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        
        Vmeas_raw = ADC_GetResult8();
        Vmeas = (uint8)Vmeas_raw;         
        Vmeas_buffer[loop_count] = Vmeas;          
            
    		/**********Kd term************/
            
            if(loop_count == 1)
            {
                Vmeas_delta = 0;
            }
            else
            {
                Vmeas_delta = Vmeas - Vmeas_last;
            }
            
            Kd_term = Kd * Vmeas_delta / Kd_scale_factor;
            if(Kd_term > d) {Kd_term = d;}
            if(Kd_term < -d) {Kd_term = -d;}
                	
    		/**********Kd term************/
            /*****************************/
            /*****************************/
            /*****************************/
            /**********Kp term************/
            
            Verror = Vref - Vmeas;
            Kp_term = Kp * Verror / Kp_scale_factor;
            if(Kp_term > p) {Kp_term = p;}
            if(Kp_term < -p) {Kp_term = -p;}
            
            /**********Kp term************/
            /*****************************/
            /*****************************/
            /*****************************/
            /**********Ki term************/
            
            Verror_sum += Verror;
            if(Verror_sum > Verror_sum_limited) {Verror_sum = Verror_sum_limited;}
            if(Verror_sum < -Verror_sum_limited) {Verror_sum = -Verror_sum_limited;}
            Ki_term = Ki * Verror_sum / Ki_scale_factor;
            if(Ki_term > i) {Ki_term = i;}
            if(Ki_term < -i) {Ki_term = -i;}
            
            /**********Ki term************/
            /*****************************/
            /*****************************/
            /*****************************/
            /***********PID term**********/
            
            Vout = FF_term + Kd_term + Kp_term + Ki_term;
            
            /***********PID term**********/
            
        if(Vout > 230)
        {
            dac_in = 230;
        }
        if(Vout < 0)
        {
            dac_in = 0;
        }
        else
        {
            dac_in = Vout;
        }       
        x = (uint8)(2*dac_in + 30)/1.25; // with proper PID scaling
        DAC_1_SetValue(x);
    }
    return;
}